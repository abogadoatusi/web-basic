const input = document.getElementById("age");
const btn = document.getElementById("check");
const result = document.getElementById("result");

btn.addEventListener("click", () => {
  const age = Number(input.value);
  // ここで if を使って result.textContent を書き換える
});
