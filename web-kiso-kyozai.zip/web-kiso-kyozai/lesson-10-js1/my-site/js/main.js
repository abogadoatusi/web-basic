const btn = document.getElementById("btn");
const msg = document.getElementById("msg");

btn.addEventListener("click", () => {
  // ここに、ボタンを押したときの動きを書く
});
