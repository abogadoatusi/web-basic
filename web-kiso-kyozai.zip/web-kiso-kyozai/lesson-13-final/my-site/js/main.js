const btn = document.getElementById("greet");
const msg = document.getElementById("msg");

if (btn) {
  btn.addEventListener("click", () => {
    msg.textContent = "こんにちは！【あなたのひとこと】";
  });
}
